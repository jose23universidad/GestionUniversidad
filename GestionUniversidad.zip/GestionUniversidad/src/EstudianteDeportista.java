/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author JKHL
 */
public class EstudianteDeportista extends Estudiante implements Deportista {
    private String deporte;

    public EstudianteDeportista(String nombre, int edad, String codigoEstudiante, String deporte) {
        super(nombre, edad, codigoEstudiante);
        this.deporte = deporte;
    }

    @Override
    public void practicarDeporte() {
        System.out.println(getNombre() + " está entrenando arduamente en el deporte: " + deporte);
    }

    @Override
    public void mostrarDatos() {
        System.out.println("[Estudiante Deportista] Nombre: " + getNombre() + " | Edad: " + getEdad() + " | Código: " + getCodigoEstudiante() + " | Deporte: " + deporte);
    }
}
