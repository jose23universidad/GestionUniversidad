/**
 *
 * @author JKHL
 */
public class Docente extends Persona {
    private String especialidad;

    public Docente(String nombre, int edad, String especialidad) {
        super(nombre, edad);
        this.especialidad = especialidad;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("[Docente] Nombre: " + getNombre() + " | Edad: " + getEdad() + " | Especialidad: " + especialidad);
    }
}