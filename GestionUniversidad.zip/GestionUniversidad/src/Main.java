/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author JKHL
 */
public class Main {
    public static void main(String[] args) {
        // Creación de las diferentes personas de la universidad
        Docente docente = new Docente("Carlos Mendoza", 45, "Cálculo Multivariable");
        Administrativo admin = new Administrativo("Ana Gómez", 38, "Recursos Humanos");
        
        EstudianteDeportista estDep = new EstudianteDeportista("Luis Pérez", 20, "EST8832", "Fútbol");
        EstudianteArtista estArt = new EstudianteArtista("María Silva", 22, "EST4411", "Tragedia Griega");
        EstudianteIntegrado estTop = new EstudianteIntegrado("Kevin Torres", 21, "EST9900", "Básquetbol", "Teatro Contemporáneo");

        // Mostrar datos en el momento adecuado
        System.out.println("--- REGISTRO DE PERSONAL DE LA UNIVERSIDAD ---");
        docente.mostrarDatos();
        admin.mostrarDatos();
        
        System.out.println("\n--- REGISTRO DE ESTUDIANTES Y ACTIVIDADES ---");
        estDep.mostrarDatos();
        estDep.practicarDeporte();
        
        System.out.println();
        estArt.mostrarDatos();
        estArt.realizarPresentacionTeatral();
        
        System.out.println();
        estTop.mostrarDatos();
        estTop.practicarDeporte();
        estTop.realizarPresentacionTeatral();
    }
}

