/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author JKHL
 */
public class EstudianteIntegrado extends Estudiante implements Deportista, Artista {
    private String deporte;
    private String grupoTeatro;

    public EstudianteIntegrado(String nombre, int edad, String codigoEstudiante, String deporte, String grupoTeatro) {
        super(nombre, edad, codigoEstudiante);
        this.deporte = deporte;
        this.grupoTeatro = grupoTeatro;
    }

    @Override
    public void practicarDeporte() {
        System.out.println(getNombre() + " (Destacado) entrena: " + deporte);
    }

    @Override
    public void realizarPresentacionTeatral() {
        System.out.println(getNombre() + " (Destacado) ensaya en: " + grupoTeatro);
    }

    @Override
    public void mostrarDatos() {
        System.out.println("[Estudiante Multitalento] Nombre: " + getNombre() + " | Edad: " + getEdad() + " | Código: " + getCodigoEstudiante() + " | Deporte: " + deporte + " | Teatro: " + grupoTeatro);
    }
}