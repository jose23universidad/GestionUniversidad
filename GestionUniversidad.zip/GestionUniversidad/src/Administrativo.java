/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author JKHL
 */
public class Administrativo extends Persona {
    private String area;

    public Administrativo(String nombre, int edad, String area) {
        super(nombre, edad);
        this.area = area;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("[Administrativo] Nombre: " + getNombre() + " | Edad: " + getEdad() + " | Área: " + area);
    }
}
