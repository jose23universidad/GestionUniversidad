/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author JKHL
 */
public class Estudiante extends Persona {
    private String codigoEstudiante;

    public Estudiante(String nombre, int edad, String codigoEstudiante) {
        super(nombre, edad);
        this.codigoEstudiante = codigoEstudiante;
    }

    public String getCodigoEstudiante() {
        return codigoEstudiante;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("[Estudiante Regular] Nombre: " + getNombre() + " | Edad: " + getEdad() + " | Código: " + codigoEstudiante);
    }
}
