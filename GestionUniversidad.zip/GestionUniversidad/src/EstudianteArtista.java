/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author JKHL
 */
public class EstudianteArtista extends Estudiante implements Artista {
    private String grupoTeatro;

    public EstudianteArtista(String nombre, int edad, String codigoEstudiante, String grupoTeatro) {
        super(nombre, edad, codigoEstudiante);
        this.grupoTeatro = grupoTeatro;
    }

    @Override
    public void realizarPresentacionTeatral() {
        System.out.println(getNombre() + " está actuando en el grupo de teatro: " + grupoTeatro);
    }

    @Override
    public void mostrarDatos() {
        System.out.println("[Estudiante Artista] Nombre: " + getNombre() + " | Edad: " + getEdad() + " | Código: " + getCodigoEstudiante() + " | Teatro: " + grupoTeatro);
    }
}
